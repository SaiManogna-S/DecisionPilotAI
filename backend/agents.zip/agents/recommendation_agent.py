from config.gemini_config import model


def recommend(reasoning: str):

    prompt = f"""
You are the Recommendation Agent.

Based on the reasoning below,

suggest the Top 5 Next Best Actions.

Reasoning:

{reasoning}

Return:

Priority:
Recommendation:
Business Impact:
Confidence:
"""

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print("Knowledge Agent Error:", e)
        return "Knowledge could not be retrieved because Gemini quota was exceeded."

    return [
  {
    "priority":"Critical",
    "title":"Immediate Executive Escalation",
    "impact":"Prevent churn",
    "confidence":96
  },
  {
    "priority":"High",
    "title":"Assign Dedicated Success Manager",
    "impact":"Resolve support issues",
    "confidence":92
  }
]