from config.gemini_config import model


def reason(customer_context: str, company_knowledge: str):

    prompt = f"""
You are the Business Reasoning Agent of NovaCRM Technologies.

Your job is NOT to search documents.

Your job is to THINK.

Customer Context:

{customer_context}

Company Knowledge:

{company_knowledge}

Analyze the situation.

Return ONLY:

Business Risk:
Business Opportunity:
Urgency:
Reasoning:
"""

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print("Knowledge Agent Error:", e)
        return "Knowledge could not be retrieved because Gemini quota was exceeded."

    return {
  "business_risk":"High",
  "urgency":"Critical",
  "confidence":96,
  "reason":"..."
}