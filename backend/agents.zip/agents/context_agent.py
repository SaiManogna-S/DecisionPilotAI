from config.gemini_config import model


def analyze_context(customer_text: str):

    prompt = f"""
You are a Customer Success AI.

Analyze the transcript and return ONLY valid JSON.

Return exactly this format:

{{
  "health_score": 35,
  "sentiment": "Negative",
  "renewal_days": 15,
  "summary": "Short summary",
  "problems": [
    "...",
    "..."
  ],
  "opportunities": [
    "...",
    "..."
  ]
}}

Transcript:

{meeting_text}
"""

    response = model.generate_content(prompt)

    return response.text