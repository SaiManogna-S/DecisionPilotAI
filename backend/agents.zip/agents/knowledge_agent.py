from rag.retriever import get_retriever
from config.gemini_config import model


retriever = get_retriever()


def search_knowledge(question: str):

    documents = retriever.invoke(question)

    context = ""

    for doc in documents:
        context += doc.page_content + "\n\n"

    prompt = f"""
You are the Enterprise Knowledge Agent of NovaCRM Technologies.

Answer ONLY using the company knowledge below.

If the answer is not present,
say:

"I could not find this information in the company knowledge base."

Company Knowledge:

{context}

Question:

{question}

Answer:
"""

    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        print("Knowledge Agent Error:", e)
        return "Knowledge could not be retrieved because Gemini quota was exceeded."

    return {
  "business_risk":"High",
  "urgency":"Critical",
  "confidence":96,
  "reason":"..."
}