from agents.context_agent import analyze_context
from agents.knowledge_agent import search_knowledge
from agents.reasoning_agent import reason
from agents.recommendation_agent import recommend


def execute_pipeline(meeting_text):

    try:
        print("Running Context Agent...")
        context = analyze_context(meeting_text)
        print(context)
    except Exception as e:
        print("Context Agent Error:", e)
        raise

    try:
        print("Running Knowledge Agent...")
        knowledge = search_knowledge(context)
        print(knowledge)
    except Exception as e:
        print("Knowledge Agent Error:", e)
        raise

    try:
        print("Running Reasoning Agent...")
        reasoning = reason(context, knowledge)
        print(reasoning)
    except Exception as e:
        print("Reasoning Agent Error:", e)
        raise

    try:
        print("Running Recommendation Agent...")
        recommendations = recommend(reasoning)
        print(recommendations)
    except Exception as e:
        print("Recommendation Agent Error:", e)
        raise

    return {
        "context": context,
        "knowledge": knowledge,
        "reasoning": reasoning,
        "recommendations": recommendations
    }